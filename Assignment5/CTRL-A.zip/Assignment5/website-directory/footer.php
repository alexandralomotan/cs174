<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="./css/styles.css" type="text/css" />
</head>

<body>
    <div id="footer">
        Team CTRL-A CS174 HW 2
    </div>
</body>

</html>