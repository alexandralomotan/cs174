<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="./css/layout.css" type="text/css" />
	<link rel="stylesheet" href="./css/styles.css" type="text/css" />
    <title>Index</title>
</head>

<body>
    <?php
        include "header.php";
	include "navbar.php";
	include "middleindex.php";
	include "footer.php";
    ?>
</body>

</html>