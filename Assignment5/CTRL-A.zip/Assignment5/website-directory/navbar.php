<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="./css/styles.css" type="text/css" />
</head>

<body>
    <div id="nav">
	<a href="./index.php">Home</a><br>
        <a href="./simple_web.php">Simple_Web</a>
	
    </div>
</body>

</html>
    